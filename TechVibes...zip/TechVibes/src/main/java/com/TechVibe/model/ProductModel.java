package com.TechVibe.model;

public class ProductModel {
    private int productId;
    private String productName;
    private double productPrice;
    private String productDescription;
    private int productCategoryId;
    private String productImage;
    private int productStock;
    private String productBrand;

    public ProductModel(int productId, String productName, double productPrice, String productDescription, int productCategoryId,
            String productImage, int productStock, String productBrand) {
        super();
        this.productId = productId;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productDescription = productDescription;
        this.productCategoryId = productCategoryId;
        this.productImage = productImage;
        this.productStock = productStock;
        this.productBrand = productBrand;
    }

    public ProductModel() {
		// TODO Auto-generated constructor stub
	}

	public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public int getProductCategoryId() {
        return productCategoryId;
    }

    public void setProductCategoryId(int productCategoryId) {
        this.productCategoryId = productCategoryId;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public int getProductStock() {
        return productStock;
    }

    public void setProductStock(int productStock) {
        this.productStock = productStock;
    }

    public String getProductBrand() {
        return productBrand;
    }

    public void setProductBrand(String productBrand) {
        this.productBrand = productBrand;
    }
}

