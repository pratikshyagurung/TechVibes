package com.TechVibe.model;



public class ProductCategoryModel {

    private int productCategoryId;
    private String categoryName;

    // Constructors
    public ProductCategoryModel() {
    }

    public ProductCategoryModel(String categoryName) {
        this.categoryName = categoryName;
    }

    // Getters and setters
    public int getcategoryId() {
        return productCategoryId;
    }

    public void setcategoryId(int productCategoryId) {
        this.productCategoryId = productCategoryId;
    }

    public String getcategoryName() {
        return categoryName;
    }

    public void setcategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    // toString method (optional)
    @Override
    public String toString() {
        return "ProductCategory [id=" + productCategoryId + ", name=" +categoryName + "]";
    }
}
