package com.TechVibe.model;
import java.io.Serializable;


public class UserProfile implements Serializable {
	public int userId;
	public String userName;
	public String firstName;
	public String lastName;
	public String userAddress;
	public String phoneNumber;
	public String dob;
	public String userEmail;
	public String userPassword;
	public String image;
	public String type;
	public UserProfile(int userId, String userName, String firstName, String lastName, String userAddress, String phoneNumber, String dob, String userEmail, String userPassword, String image, String type) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.firstName = firstName;
		this.lastName = lastName;
		this.userAddress = userAddress;
		this.phoneNumber = phoneNumber;
		this.dob = dob;
		this.userEmail = userEmail;
		this.userPassword = userPassword;
		this.image = image;
		this.type = type;
	}
	public UserProfile() {}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String username) {
		this.userName = username;
	}
	public String getFistName() {
		return firstName;
	}
	public void setFirstName(String firstname) {
		this.firstName = firstname;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastname) {
		this.lastName = lastname;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String address) {
		this.userAddress = address;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNumber = phoneNo;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dateofbirth) {
		this.dob = dateofbirth;
	}
	public String getEmail() {
		return userEmail;
	}
	public void setEmail(String email) {
		this.userEmail = email;
	}
	public String getPassword() {
		return userPassword;
	}
	public void setPassword(String password) {
		this.userPassword = password;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
