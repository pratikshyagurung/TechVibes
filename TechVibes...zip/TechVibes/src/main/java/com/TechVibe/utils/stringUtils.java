package com.TechVibe.utils;

public class stringUtils {
	public static final String INSERT_USER = "INSERT INTO user(userName, firstName, lastName, dob, gender, userEmail, phoneNumber, userPassword, userRole) VALUE (?,?,?,?,?,?,?,?,?)";
	public static final String GET_LOGIN_INFO = "SELECT * FROM user WHERE userName = ? AND userPassword = ?";
	public static final String ADMIN = "SELECT userRole FROM user WHERE userName = ?" ;
	public static final String GET_ALL_USER_INFO = "SELECT * FROM user ";
	
	public static final String USER_NAME = "userName";
	public static final String FIRST_NAME = "firstName";
	public static final String LAST_NAME = "lastName";
	public static final String DOB = "dob";
	public static final String EMAIL = "email";
	public static final String GENDER = "gender";
	public static final String PHONE_NUMBER = "phoneNumber";
	public static final String PASSWORD = "password";
	public static final String RE_PASSWORD = "repassword";
	public static final String getADMIN = "Select * from user WHERE userRole = ?";
	
	public static final String SUCCESS_SIGNUP_MESSAGE = "Successfully Signup!";
	public static final String SIGNUP_ERROR_MESSAGE = "Please correct thr form data.";
	public static final String SERVER_ERROR_MESSAGE = "An unexpected server error occured.";
	public static final String ERROR_MESSAGE = "An unexpected  error occured.";

	public static final String SUCCESS_MESSAGE = "SuccessMessage";
	

	public static final String LOGIN_PAGE = "../Pages/Login.jsp";
	public static final String SIGNUP_PAGE = "../Pages/Signup.jsp";


	public static final String SIGNUP_SERVLET = "../SignupServlet";
	
	
	

}