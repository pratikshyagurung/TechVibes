package com.TechVibe.utils;

import java.util.Base64;
import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class Encryption {

	private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/ECB/PKCS5Padding";
	
	public String encryptPassword(String password) {
		byte[] encrypt = Base64.getEncoder().encode(password.getBytes());
		return new String(encrypt);
	}
	
	public String decryptPassword(String encryptedPassword) {
		byte[] decrypt = Base64.getDecoder().decode(encryptedPassword);
		return new String(decrypt);
	}
	
	
	public static void main(String[] args) {
		String password = "Pratiksha";
		Encryption encrypt = new Encryption();
		System.out.println(encrypt.encryptPassword(password));
		
		
		System.out.println(encrypt.decryptPassword(encrypt.encryptPassword(password)));
	}
	
	public String encryptMessage(byte[] message, byte[] keyBytes) throws InvalidKeyException, NoSuchPaddingException,
		NoSuchAlgorithmException, BadPaddingException, IllegalBlockSizeException {
		Cipher cipher = Cipher.getInstance(TRANSFORMATION);
		SecretKey secretKey = new SecretKeySpec(keyBytes, ALGORITHM);
		cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		byte[] encryptedMessage = cipher.doFinal(message);
		return new String(encryptedMessage);
		}
		
		public String decryptMessage(byte[] encryptedMessage, byte[] keyBytes) throws NoSuchPaddingException,
		    NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
		Cipher cipher = Cipher.getInstance(TRANSFORMATION);
		SecretKey secretKey = new SecretKeySpec(keyBytes, ALGORITHM);
		cipher.init(Cipher.DECRYPT_MODE, secretKey);
		byte[] clearMessage = cipher.doFinal(encryptedMessage);
		return new String(clearMessage);
}


}