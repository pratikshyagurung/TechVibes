package com.TechVibe.controller.servlet;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.TechVibe.controller.Dao.ProductDao;
import com.TechVibe.model.ProductModel;

/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("/ProductServlet")
@MultipartConfig(maxFileSize = 16177215) // Around 16MB
public class ProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private ProductDao pd = new ProductDao();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productName = request.getParameter("productName");
        String productStockParam = request.getParameter("productStock");
        String productDescription = request.getParameter("productDescription");
        String categoryIdParam = request.getParameter("productCategoryId");
        String productPriceParam = request.getParameter("productPrice");

        Part filePart = request.getPart("file1");
        String filename = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
        String savePath = "C:\\Users\\ASUS\\eclipse-workspace\\TechVibes\\src\\main\\webapp\\Images\\" + filename;
        String databasePath = "Images/" + filename;

        // Save file to disk
        try (InputStream fileContent = filePart.getInputStream();
             FileOutputStream outputStream = new FileOutputStream(savePath)) {
            fileContent.transferTo(outputStream);
        } catch (IOException e) {
            // Handle file save error
            response.sendRedirect("errorPage.jsp?message=Failed to save file");
            return;
        }

        // Create and save product
        try {
            int productStock = Integer.parseInt(productStockParam);
            int categoryId = Integer.parseInt(categoryIdParam);
            double productPrice = Double.parseDouble(productPriceParam);

            ProductModel product = new ProductModel(0, productName, productPrice, productDescription, categoryId, databasePath, productStock, null);
            pd.saveProduct(product);
        } catch (Exception e) {
            response.sendRedirect("errorPage.jsp?message=Failed to save product");
            return;
        }
    }
        
        protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
        
            String productName = request.getParameter("productName");
            String productStockParam = request.getParameter("productStock");
            String productDescription = request.getParameter("productDescription");
            String categoryIdParam = request.getParameter("productCategoryId");
            String productPriceParam = request.getParameter("productPrice");

            Part filePart = request.getPart("file1");
            String filename = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
            String savePath = "C:\\Users\\97798\\eclipse-workspace\\TechVibe\\src\\main\\webapp\\Images\\" + filename;
            String databasePath = "Images/" + filename;

            // Save file to disk
            try (InputStream fileContent = filePart.getInputStream();
                 FileOutputStream outputStream = new FileOutputStream(savePath)) {
                fileContent.transferTo(outputStream);
            } catch (IOException e) {
                // Handle file save error
                response.sendRedirect("errorPage.jsp?message=Failed to save file");
                return;
            }

            // Create and save product
            try {
                int productStock = Integer.parseInt(productStockParam);
                int categoryId = Integer.parseInt(categoryIdParam);
                double productPrice = Double.parseDouble(productPriceParam);

                ProductModel product = new ProductModel(0, productName, productPrice, productDescription, categoryId, databasePath, productStock, null);
                pd.saveProduct(product);
            } catch (Exception e) {
                response.sendRedirect("errorPage.jsp?message=Failed to save product");
                return;
            }

        response.sendRedirect(request.getContextPath() + "/Admin/addProduct.jsp");
    }
}
