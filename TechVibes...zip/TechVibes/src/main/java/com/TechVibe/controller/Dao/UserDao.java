package com.TechVibe.controller.Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.TechVibe.controller.dbcontroller.DatabaseController;
import com.TechVibe.model.UserModel;
import com.TechVibe.utils.Encryption;
import com.TechVibe.utils.stringUtils;

public class UserDao {
	Encryption encrypt = new Encryption();
	
		
	
	    private Connection conn;

	    public UserDao() {
	        try {
	            this.conn = DatabaseController.getConnections();
	        } catch (Throwable e) {
	            throw new RuntimeException("Failed to get database connection", e);
	        }
	    }
	    public int admin( String userName) {
			try(Connection conn = DatabaseController.getConnections()){
			String userRole = null;
			PreparedStatement st = conn.prepareStatement(stringUtils.ADMIN);
			
			st.setString(1,userName);
			
			ResultSet rs = st.executeQuery();
			
			while  (rs.next()) 
			{
				 userRole= rs.getString("userRole");
				 

			}
			System.out.println(userRole);
//			if ("customer".equals(userRole)) {
//				return 0;
//				
//			}
//			else {
//				return 1;
//			}
			
			if(userRole.equals("0")) {
				return 0;
			}
			else {
				return 1;
			}
			
		
			
			
			
			}
			catch (SQLException | ClassNotFoundException ex) {
				ex.printStackTrace();
				return -1 ;
		}
			
		}
		public int addUser(UserModel userModel) {
			
		
			
			
				try(Connection conn = DatabaseController.getConnections()){
				PreparedStatement st = conn.prepareStatement(stringUtils.INSERT_USER);
			
				st.setString(1, userModel.getUserName());
				st.setString(2, userModel.getFirstName());
				st.setString(3, userModel.getLastName());
				st.setDate(4, Date.valueOf(userModel.getDob()));
				st.setString(5, userModel.getGender());
				st.setString(6, userModel.getEmail());
				st.setInt(7, userModel.getPhoneNumber());
				st.setString(8, encrypt.encryptPassword(userModel.getPassword()));
				st.setString(9, "0");
			
			System.out.println(userModel.getUserName());
			System.out.println(userModel.getFirstName());
			System.out.println(userModel.getLastName());
			System.out.println(userModel.getDob());
			System.out.println(userModel.getGender());
			System.out.println(userModel.getEmail());
			System.out.println(userModel.getPhoneNumber());
			System.out.println(userModel.getPassword());
			
				int result = st.executeUpdate ();
				return result > 0 ? 1 : 0;
		} 	catch (SQLException | ClassNotFoundException ex) {
				ex.printStackTrace();
				return -1;
		}
		}
		
		public int get_user_Login_Info(String username,String password) {
			try(Connection conn = DatabaseController.getConnections()){
				PreparedStatement st = conn.prepareStatement(stringUtils.GET_LOGIN_INFO);
				st.setString(1,  username);
				st.setString(2,  encrypt.encryptPassword(password));
				ResultSet rs = st.executeQuery();
				
				if (rs.next ()) {
					return 1;
				} else {
					return 0;
				}
			}catch (SQLException | ClassNotFoundException ex) {
				ex.printStackTrace ();
				return -1;
			}
		}
		//username  already exists
	    public boolean isUsernameExists(String username) {
	    	try(Connection conn = DatabaseController.getConnections()){
	            PreparedStatement ps = conn.prepareStatement("SELECT * FROM user WHERE username = ?");
	            ps.setString(1, username);
	            ResultSet rs = ps.executeQuery();
	            if (rs.next()) {
	                return true; // Username exists
	            }
	        } catch (SQLException | ClassNotFoundException ex) {
	            ex.printStackTrace(); // Handle or log the exception properly
	        }
	        return false; // Username does not exist
	    }
	      
//	        isEmailExists
			public boolean isEmailExists(String email) {
				try (Connection con = DatabaseController.getConnections()) {
					PreparedStatement ps = con.prepareStatement("SELECT * FROM user WHERE email = ?");
					ps.setString(1, email);
					ResultSet rs = ps.executeQuery();
					if (rs.next()) {
						return true;
					}
				} catch (SQLException | ClassNotFoundException ex) {
					ex.printStackTrace();
				}
				return false;
			}
			
			//isPhoneNumberExists
			public boolean isPhoneNumberExists(String phoneNumber) {
				try(Connection conn = DatabaseController.getConnections()){
					PreparedStatement ps = conn.prepareStatement("SELECT * FROM user WHERE phoneNumber = ?");
					ps.setString(1, phoneNumber);
					ResultSet rs = ps.executeQuery();
					if (rs.next()) {
						return true;
					}
				} catch (SQLException | ClassNotFoundException ex) {
					ex.printStackTrace();
				}
				return false;
			}
	}
