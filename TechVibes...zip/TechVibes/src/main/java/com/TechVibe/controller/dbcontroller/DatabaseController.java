package com.TechVibe.controller.dbcontroller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseController {
	 // Method to establish a database connection
		public static Connection getConnections() throws SQLException, ClassNotFoundException {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/techvibe";
			String user = "root";
			String password = "";
			return DriverManager.getConnection(url, user, password);
		}

}


