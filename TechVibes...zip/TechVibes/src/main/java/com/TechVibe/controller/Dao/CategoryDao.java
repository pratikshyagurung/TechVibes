package com.TechVibe.controller.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.TechVibe.controller.dbcontroller.DatabaseController;
import com.TechVibe.model.ProductCategoryModel;

public class CategoryDao {
	 private Connection conn;

	   

	    public CategoryDao() throws ClassNotFoundException, SQLException {
	        this.conn = new DatabaseController().getConnections();
	        // Assuming DatabaseController provides getConnection() method
	    }

	    // Method to add a new product category
	   
	       

	    // Method to get all product categories
	    public List<ProductCategoryModel> getAllProductCategories() {
	        List<ProductCategoryModel> categories = new ArrayList<>();
	        String query = "SELECT * FROM productcategory";
	        try {
	            PreparedStatement preparedStatement = conn.prepareStatement(query);
	            ResultSet resultSet = preparedStatement.executeQuery();
	            while (resultSet.next()) {
	            	ProductCategoryModel category = new ProductCategoryModel();
	                category.setcategoryId(resultSet.getInt("productCategoryId"));
	                category.setcategoryName(resultSet.getString("categoryName"));
	                categories.add(category);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return categories;
	    }

	   
	 

	    // Method to delete a product category
	    public void deleteProductCategory(int categoryId) {
	        String query = "DELETE FROM productCategory WHERE categoryId=?";
	        try {
	            PreparedStatement preparedStatement = conn.prepareStatement(query);
	            preparedStatement.setInt(1, categoryId);
	            preparedStatement.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
}
