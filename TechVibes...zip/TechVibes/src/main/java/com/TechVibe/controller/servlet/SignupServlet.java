package com.TechVibe.controller.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SignupServlet
 */
import java.io.PrintWriter;
import java.time.LocalDate;







/**
// * Servlet implementation class SignupServlet
// */
//@WebServlet("/SignupServlet")
//public class SignupServlet extends HttpServlet {
//	private static final long serialVersionUID = 1L;
//       DatabaseController dbController = new DatabaseController();
//    /**
//     * @see HttpServlet#HttpServlet()
//     */
//    public SignupServlet() {
//        super();
//        // TODO Auto-generated constructor stub
//    }
//
//	/**
//	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
//	 */
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
//	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		
//		
//		response.setContentType("text/html");
//    	PrintWriter out = response.getWriter(); 
//        String userName = request.getParameter(stringUtils.USER_NAME);
//        String firstName = request.getParameter(stringUtils.FIRST_NAME);
//        String lastName = request.getParameter(stringUtils.LAST_NAME);
//        String dob = request.getParameter(stringUtils.DOB);
//        LocalDate DateOfBirth = LocalDate.parse(dob);
//        String email = request.getParameter(stringUtils.EMAIL);
//        String gender = request.getParameter(stringUtils.GENDER);
//        String phoneNumber = request.getParameter(stringUtils.PHONE_NUMBER);
//        int phoneNo = Integer.parseInt(phoneNumber);
//        String password = request.getParameter(stringUtils.PASSWORD);
//        String retypePassword = request.getParameter("repassword");
//        
//        
//        if(!firstName.matches("^[A-Za-z]+$") || !lastName.matches("^[A-Za-z]+$")) {
//        	out.println(userName);
//			out.println(firstName);
//			out.println(lastName);
//			out.println(dob);
//			out.println(email);
//			out.println(gender);
//		
//			out.println(phoneNumber);
//		
//			out.println(password);
//			
//		
//		    String errorMessage = "Please follow rule properly";
//		    request.setAttribute("errorMessage", errorMessage);
//		    request.getRequestDispatcher("../Pages/Signup.jsp").forward(request, response);
//		} else if (!password.equals(retypePassword)) {
//			out.println(userName);
//			out.println(firstName);
//			out.println(lastName);
//			out.println(dob);
//			out.println(email);
//			out.println(gender);
//			out.println(phoneNumber);
//			out.println(password);
//			
//		    String errorMessage = "Password Error";
//		    request.setAttribute("errorMessage", errorMessage);
//		    request.getRequestDispatcher("../Pages/Signup.jsp").forward(request, response);
//		}else {
//			
//		
//			
//		// Create a new StudentModel object with the form data
//			userModel usermodel = new userModel(userName, firstName, lastName, DateOfBirth, email,gender, phoneNo, password);
//			int result = dbController.addUser(usermodel);
//			// Provide feedback to the user
//			if(result > 0) {
//				request.getRequestDispatcher("/Pages/Login.jsp").forward(request, response);
//			
//										} else {
//				out.println(userName);
//				out.println(firstName);
//				out.println(lastName);
//				out.println(dob);
//				out.println(email);
//				out.println(gender);
//		
//				out.println(phoneNumber);
//				out.println(password);
//				out.println(result);
//			    String errorMessage = "Server Error";
//			    request.setAttribute("errorMessage", errorMessage);
//			    request.getRequestDispatcher("../Pages/Signup.jsp").forward(request, response);
//			}
//		}
//        
//	}package Controller.Servlet;



import com.TechVibe.utils.*;
import com.TechVibe.controller.Dao.UserDao;
import com.TechVibe.model.UserModel;


@WebServlet("/SignupServlet")
public class SignupServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 UserDao dbController = new UserDao();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignupServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		response.setContentType("text/html");
    	PrintWriter out = response.getWriter(); 
        String userName = request.getParameter(stringUtils.USER_NAME);
        String firstName = request.getParameter(stringUtils.FIRST_NAME);
        String lastName = request.getParameter(stringUtils.LAST_NAME);
        String dob = request.getParameter(stringUtils.DOB);
        LocalDate DateOfBirth = LocalDate.parse(dob);
        String email = request.getParameter(stringUtils.EMAIL);
        String gender = request.getParameter(stringUtils.GENDER);
      
        String phoneNumber = request.getParameter(stringUtils.PHONE_NUMBER);
        int phoneNo = Integer.parseInt(phoneNumber);
        String password = request.getParameter(stringUtils.PASSWORD);
        String retypePassword = request.getParameter("repassword");
        
        
        if(!firstName.matches("^[A-Za-z]+$") || !lastName.matches("^[A-Za-z]+$")) {
        	out.println(userName);
			out.println(firstName);
			out.println(lastName);
			out.println(dob);
			out.println(email);
			out.println(gender);
			out.println(phoneNumber);
			out.println(password);
		
		    String errorMessage = "Please follow rule properly";
		    request.setAttribute("errorMessage", errorMessage);
		    request.getRequestDispatcher("../Pages/Signup.jsp").forward(request, response);
		} else if (!password.equals(retypePassword)) {
			out.println(userName);
			out.println(firstName);
			out.println(lastName);
			out.println(dob);
			out.println(email);
			out.println(gender);
	
			out.println(phoneNumber);
			out.println(password);
			
		
		    String errorMessage = "Password Error";
		    request.setAttribute("errorMessage", errorMessage);
		    request.getRequestDispatcher("/Pages/Signup.jsp").forward(request, response);
		}else {
			
		
			
		// Create a new StudentModel object with the form data
			UserModel usermodel = new UserModel(userName, firstName, lastName, DateOfBirth, email,gender, phoneNo, password);
			int result = dbController.addUser(usermodel);
			// Provide feedback to the user
			if(result > 0) {
				request.getRequestDispatcher("Pages/Login.jsp").forward(request, response);
//			    response.sendRedirect("Login.jsp");

			
										} else {
				out.println(userName);
				out.println(firstName);
				out.println(lastName);
				out.println(dob);
				out.println(email);
				out.println(gender);
				out.println(phoneNumber);
				out.println(password);
				out.println(result);
			    String errorMessage = "Server Error";
			    request.setAttribute("errorMessage", errorMessage);
			    request.getRequestDispatcher("../Pages/Signup.jsp").forward(request, response);
			}
		}
        
	}

}