package com.TechVibe.controller.dbcontroller;

public class DatabaseCredentials {
	private static final String DB_NAME = "techvibe";
    private static final String userName = "root";
    private static final String userPassword = "";

    public static String getDbName() {
        return DB_NAME;
    }
    public static String getUserName() {
        return userName;
    }
    public static String getPassword() {
        return userPassword;
    }
}
