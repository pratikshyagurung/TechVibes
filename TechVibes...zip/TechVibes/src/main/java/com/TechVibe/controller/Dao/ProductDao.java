package com.TechVibe.controller.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.TechVibe.controller.dbcontroller.DatabaseController;
import com.TechVibe.model.ProductModel;

public class ProductDao {
    private Connection conn;

    public ProductDao() {
        try {
            this.conn = DatabaseController.getConnections();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace(); // Consider replacing with logger
            throw new RuntimeException("Failed to get database connection", e);
        }
    }

    public void saveProduct(ProductModel product) throws SQLException {
        String sql = "INSERT INTO Product (productName, productPrice, productDescription, productImage, productCategoryId, productStock) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement st = conn.prepareStatement(sql)) {
            st.setString(1, product.getProductName());
            st.setDouble(2, product.getProductPrice());
            st.setString(3, product.getProductDescription());
            st.setString(4, product.getProductImage());
            st.setInt(5, product.getProductCategoryId());
            st.setInt(6, product.getProductStock());
            st.executeUpdate();
        } catch (SQLException e) {
            // Log here
            throw new SQLException("Error saving product", e);
        }
    }

    public List<ProductModel> getAllProducts() throws SQLException, ClassNotFoundException {
        List<ProductModel> products = new ArrayList<>();
        String sql = "SELECT * FROM Product";
        try (Connection conn = DatabaseController.getConnections();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) { //result set to store the details 
            while (rs.next()) {
            	ProductModel product = new ProductModel();
                product.setProductName(rs.getString("productName"));
                product.setProductPrice(rs.getDouble("productPrice"));
                product.setProductDescription(rs.getString("productDescription"));
                product.setProductImage(rs.getString("productImage"));
                product.setProductCategoryId(rs.getInt("productCategoryId"));
                product.setProductStock(rs.getInt("productStock"));
                products.add(product);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();  // For development only. Consider a logger for production
            throw e;  // Rethrowing the exception to be handled or logged by the caller
        }
        return products;
    }


public void editProduct(ProductModel product) throws SQLException {
    String sql = "UPDATE INTO Product (productName, productPrice, productDescription, productImage, productCategoryId, productStock) VALUES (?, ?, ?, ?, ?, ?)";
    try (PreparedStatement st = conn.prepareStatement(sql)) {
        st.setString(1, product.getProductName());
        st.setDouble(2, product.getProductPrice());
        st.setString(3, product.getProductDescription());
        st.setString(4, product.getProductImage());
        st.setInt(5, product.getProductCategoryId());
        st.setInt(6, product.getProductStock());
        st.executeUpdate();
    } catch (SQLException e) {
        // Log here
        throw new SQLException("Error saving product", e);
    }
}

public List<ProductModel> cartProduct() {
	String query = "SELECT * from Product";
	List<ProductModel> products = new ArrayList<>();
	try {
		Connection conn = DatabaseController.getConnections();
		PreparedStatement st = conn.prepareStatement(query);
	
	ResultSet rs = st.executeQuery();
	while(rs.next()) {
	ProductModel product = new ProductModel( 
			rs.getInt("productId"),
			rs.getString("productName"),
			rs.getDouble("productPrice"),
			rs.getString("productDescription"),
			rs.getInt("productCategoryId"),
			rs.getString("productImage"),
			rs.getInt("productStock"),
			rs.getString("productBrand"));
	product.setproductId(rs.getString("productId"));
	product.add(product);
	System.out.println(product);
	
	}
}

catch (SQLException | ClassNotFoundException ex) {
	ex.printStackTrace();
}
	return ; 
}
}
