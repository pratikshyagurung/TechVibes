package com.TechVibe.controller.servlet;

public class UserQueryStrings {
    protected static final String GET_USERS = "SELECT * FROM users";
    protected static final String GET_USER_BY_ID = "SELECT * FROM users WHERE userId = ?";
    protected static final String UPDATE_USER = "UPDATE users SET userName = ?, firstName = ?, lastName = ?, userAddress = ?, phoneNumber = ?, dob = ?, userEmail = ?, userPassword = ?, image = ? WHERE userId = ?";
}
