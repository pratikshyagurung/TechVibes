package com.TechVibe.controller.servlet;

import com.TechVibe.controller.dbcontroller.*;
import com.TechVibe.utils.Encryption;
import com.TechVibe.utils.ImageUploader;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/edit-user")
@MultipartConfig
public class EditProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private DatabaseConnection dc;

    public EditProfileServlet() {
        super();
        this.dc = new DatabaseConnection();
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String encKeyString = "1234567890123456";

        Encryption cipherClassDemo = new Encryption();

        ImageUploader imageUploader = new ImageUploader();
        int user_Id = 0;

        try{
            user_Id = Integer.parseInt(request.getParameter("user_Id"));
        } catch (NumberFormatException e) {
            // SET ERROR MESSAGE
            System.out.println("Caught exception: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "pages/Signup.jsp");
            return;
        }

        String userName = request.getParameter("userName");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");     
        String userAddress = request.getParameter("userAddress");
        String phoneNumber = request.getParameter("phoneNumber");
        String dob = request.getParameter("dob");
        String userEmail = request.getParameter("userEmail");
        String userPassword = request.getParameter("userPassword");
        String imagePath = "";

        if (userName == null || firstName == null || lastName == null || userAddress == null || phoneNumber == null || dob == null || userEmail == null || userPassword == null) {
            // SET ERROR MESSAGE
        	response.sendRedirect(request.getContextPath() + "error.jsp");
            System.out.println("Caught exception: " + "Null values");
            response.sendRedirect(request.getContextPath() + "pages/Signup.jsp");
            return;
        }
        if (userName.isBlank() || firstName.isBlank() || lastName.isBlank() ||userAddress.isBlank() || phoneNumber.isBlank() || dob.isBlank() || userEmail.isBlank() || userPassword.isBlank()) {
            // SET ERROR MESSAGE
        	response.sendRedirect(request.getContextPath() + "error.jsp");
            System.out.println("Caught exception: " + "Blank values");
            response.sendRedirect(request.getContextPath() + "pages/Signup.jsp");
            return;
        }
        if (userPassword.length() < 8) {
            // SET ERROR MESSAGE
        	response.sendRedirect(request.getContextPath() + "error.jsp");
            System.out.println("Caught exception: " + "Password length less than 8");
            response.sendRedirect(request.getContextPath() + "/pages/Signup.jsp");
            return;
        }

        try {
            Part file = request.getPart("user_image");
            imagePath = imageUploader.saveImage(file, "/uploads/", getServletContext().getRealPath("/") + "uploads/");
        }catch (Exception e) {
            // SET ERROR MESSAGE
        	response.sendRedirect(request.getContextPath() + "error.jsp");
        	imagePath = request.getParameter("oldImage");
            e.printStackTrace();
            return;
        }

        try {
            String encryptedStr = cipherClassDemo.encryptMessage(userPassword.getBytes(), encKeyString.getBytes());

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = this.dc.getConnect();

            PreparedStatement ps = con.prepareStatement(UserQueryStrings.UPDATE_USER);
            ps.setString(1, userName);
            ps.setString(2, firstName);
            ps.setString(3, lastName);
            ps.setString(4, userAddress);
            ps.setString(5, phoneNumber);
            ps.setString(6, dob);
            ps.setString(7, userEmail);
            ps.setString(8, userPassword);
            ps.setString(9, encryptedStr);
            ps.setString(10, imagePath);
            ps.setInt(11, user_Id);

            ps.execute();
            ps.close();
            con.close();
        }catch (SQLException | ClassNotFoundException e) {
            // SET ERROR MESSAGE
        	response.sendRedirect(request.getContextPath() + "error.jsp");
            e.printStackTrace();
        }catch (Exception e) {
            // SET ERROR MESSAGE
        	response.sendRedirect(request.getContextPath() + "error.jsp");
            e.printStackTrace();
        }
        response.sendRedirect("Client/update-profile.jsp");
    }
}