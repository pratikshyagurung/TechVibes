package com.TechVibe.controller.Dao;

import java.sql.Connection;

import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.TechVibe.model.UserModel;
import com.TechVibe.utils.stringUtils;


public class UpdateUserDao {

		public Connection getConnections() throws SQLException, ClassNotFoundException {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/techvibe";
			String user = "root";
			String pass = "";
			return DriverManager.getConnection(url, user, pass);
			 
		}
		public int admin( String userName) {
			try(Connection con = getConnections()){
			String userRole = " ";
			PreparedStatement st = con.prepareStatement(stringUtils.ADMIN);
			
			st.setString(1,userName);
			
			ResultSet rs = st.executeQuery();
			
			while  (rs.next()) 
			{
				 userRole= rs.getString("userRole");
				 

			}
			System.out.println(userRole);
			if ("customer".equals(userRole)) {
				return 0;
				
			}
			else {
				return 1;
			}
			
		
			
	
			
			
			
			}
			catch (SQLException | ClassNotFoundException ex) {
				ex.printStackTrace();
				return -1 ;
		}
			
		}
		public int addUser(UserModel userModel) {
			try(Connection con = getConnections()){
				PreparedStatement st = con.prepareStatement(stringUtils.INSERT_USER);
			
				st.setString(1, userModel.getUserName());
				st.setString(2, userModel.getFirstName());
				st.setString(3, userModel.getLastName());
				st.setDate(4, Date.valueOf(userModel.getDob()));
				st.setString(5, userModel.getGender());
				st.setString(6, userModel.getEmail());
				st.setInt(7, userModel.getPhoneNumber());
				st.setString(8, userModel.getPassword());
				st.setString(9, "customer");
				
			System.out.println(userModel.getUserName());
			System.out.println(userModel.getFirstName());
			System.out.println(userModel.getLastName());
			System.out.println(userModel.getDob());
			System.out.println(userModel.getGender());
			System.out.println(userModel.getEmail());
			System.out.println(userModel.getPhoneNumber());
			System.out.println(userModel.getPassword());
			
				int result = st.executeUpdate ();
				return result > 0 ? 1 : 0;
		} 	catch (SQLException | ClassNotFoundException ex) {
				ex.printStackTrace();
				return -1;
		}
		}
		
		public int get_user_Login_Info(String username,String password) {
			try (Connection con = getConnections()){
				PreparedStatement st = con.prepareStatement(stringUtils.GET_LOGIN_INFO);
				st.setString(1,  username);
				st.setString(2,  password);
				ResultSet rs = st.executeQuery();
				
				if (rs.next ()) {
					return 1;
				} else {
					return 0;
				}
			}catch (SQLException | ClassNotFoundException ex) {
				ex.printStackTrace ();
				return -1;
			}
		}
		//username  already exists
	    public boolean isUsernameExists(String username) {
	        try (Connection con = getConnections()) {
	            PreparedStatement ps = con.prepareStatement("SELECT * FROM user WHERE username = ?");
	            ps.setString(1, username);
	            ResultSet rs = ps.executeQuery();
	            if (rs.next()) {
	                return true; // Username exists
	            }
	        } catch (SQLException | ClassNotFoundException ex) {
	            ex.printStackTrace(); // Handle or log the exception properly
	        }
	        return false; // Username does not exist
	    }
	      
//	        isEmailExists
			public boolean isEmailExists(String email) {
				try (Connection con = getConnections()) {
					PreparedStatement ps = con.prepareStatement("SELECT * FROM user WHERE email = ?");
					ps.setString(1, email);
					ResultSet rs = ps.executeQuery();
					if (rs.next()) {
						return true;
					}
				} catch (SQLException | ClassNotFoundException ex) {
					ex.printStackTrace();
				}
				return false;
			}
			
			//isPhoneNumberExists
			public boolean isPhoneNumberExists(String phoneNumber) {
				try (Connection con = getConnections()) {
					PreparedStatement ps = con.prepareStatement("SELECT * FROM user WHERE phoneNumber = ?");
					ps.setString(1, phoneNumber);
					ResultSet rs = ps.executeQuery();
					if (rs.next()) {
						return true;
					}
				} catch (SQLException | ClassNotFoundException ex) {
					ex.printStackTrace();
				}
				return false;
			}
			
			

	}
