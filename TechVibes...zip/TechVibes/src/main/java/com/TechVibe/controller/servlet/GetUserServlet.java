package com.TechVibe.controller.servlet;

import com.TechVibe.controller.dbcontroller.*;
import com.TechVibe.model.UserProfile;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.annotation.WebServlet;

@WebServlet("/get-users")
public class GetUserServlet{
    private DatabaseConnection dc;

    public GetUserServlet() {
        super();
        this.dc = new DatabaseConnection();
    }

    public UserProfile getAUser(int userId) throws SQLException, ClassNotFoundException {
        UserProfile user = null;
        Connection con = this.dc.getConnect();

        try{
            Class.forName("com.mysql.cj.jdbc.Driver");

            PreparedStatement ps = con.prepareStatement(UserQueryStrings.GET_USER_BY_ID);
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            if(!rs.next()) {
				// SET ERROR MESSAGE
                return null;
            }

            do{
                user = new UserProfile(
                    rs.getInt("userId"),
                    rs.getString("userName"),
                    rs.getString("firstName"),
                    rs.getString("lastName"),
                    rs.getString("userAddress"),
                    rs.getString("phoneNumber"),
                    rs.getString("dob"),
                    rs.getString("userEmail"),
                    rs.getString("userPassword"),
                    rs.getString("image"),
                    rs.getString("type"));
            } while (rs.next());

            ps.close();
            con.close();

        } catch (Exception e) {
            // SET ERROR MESSAGE
            e.printStackTrace();
        
        }
 
        return user;
    }
}