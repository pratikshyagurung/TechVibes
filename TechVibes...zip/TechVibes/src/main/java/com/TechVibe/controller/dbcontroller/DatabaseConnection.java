package com.TechVibe.controller.dbcontroller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
	public Connection getConnect(){
        Connection con = null;

        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/techvibe"+DatabaseCredentials.getDbName(),
                    DatabaseCredentials.getUserName(),DatabaseCredentials.getPassword());
            if(con!=null) {
                System.out.println("Connection is successful");
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return con;
    }
}
